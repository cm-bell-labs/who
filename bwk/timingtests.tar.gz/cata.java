// default (apparently unbuffered) i/o

import java.io.*;
import java.util.*;

public class cata {

public static void main(String args[]) throws IOException {
	int b;

	DataInputStream in = new DataInputStream(System.in);
	DataOutputStream out = new DataOutputStream(System.out);

	Date d0 = new Date();
	try {
		while (true) {
			b = in.readByte();
			out.writeByte(b);
		}
	} catch (Exception e) {;}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();

	System.err.println(dt + " msec");
}

}
