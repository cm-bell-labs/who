$\ = "\n";              # set output record separator

while (<>) {
    ($Fld1) = split;
    $S += $Fld1;
}

print $S;
