// usage: wc input

import java.io.*;
import java.util.*;

public class wc {

// wc file

public static void main(String args[]) throws IOException {
	wc t = new wc();
	t.runwc(args);
}

public String runwc(String args[])  {
	int nl = 0, nw = 0, nc = 0;
	int b;
	boolean inword = false;
	FileInputStream fin0;

	Date d0 = new Date();
	try {
		fin0 = new FileInputStream(args[0]);
		BufferedInputStream fin = new BufferedInputStream(fin0, 8192);
		while ((b = fin.read()) > -1) {
			++nc;
			if (b == '\n')
				++nl;
			if (Character.isSpace((char)b))
				inword = false;
			else if (inword == false) {
				++nw;
				inword = true;
			}
		}
		fin.close();
	} catch (Exception e) {System.err.println(e);}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = nl + " " + nw + " " + nc;
	System.out.println(ret);
	System.out.println(dt + " msec");
	return ret;
}

}
