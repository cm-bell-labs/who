import java.awt.*;
import java.util.*;

class text extends Frame {
	
TextArea trans = new TextArea(24,60);
Button go = new Button("Go");
TextField n = new TextField("200");
Button quit = new Button("Quit");

public static void main (String args[]) {
	text t = new text();
}

text() {
	setLayout(new FlowLayout());
	add(go);
	add(n);
	add(trans);
	add(quit);
	pack();
	show();
}

public void doit() {
	Date d0 = new Date();
	int lim = Integer.parseInt(n.getText());

	trans.setText("");
	for (int i = 1; i <= lim; i++) {
		trans.appendText(i + "\n");
 Toolkit.getDefaultToolkit().sync();

	}
	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	trans.appendText("time = " + dt + "\n");
}

public boolean action(Event e, Object what) 
{
	boolean stat = true;
	String retval = "";

	Date d0 = new Date();
	if (e.target == quit) {
		hide();
		dispose();
		System.exit(0);
	} else if (e.target == go) {
		doit();
	} else {
		stat = false;
	}
	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	System.err.println(dt + " msec");
	return stat;
}

}
