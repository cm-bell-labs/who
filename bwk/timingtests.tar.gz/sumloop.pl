$\ = "\n";

$n = $ARGV[0];

for ($i = 0; $i < $n; $i++) {
	$sum++;
}
print $sum
