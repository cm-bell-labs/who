// usage: sum1 rn100

import java.io.*;
import java.util.*;

public class sum1 {

public static void main(String args[]) {
	sum1 t = new sum1();
	t.runsum1(args);
}

public String runsum1(String args[])  {
	double sum = 0, d;
	String s;

	Date d0 = new Date();
	try {
		FileInputStream fin = new FileInputStream(args[0]);
		BufferedInputStream bin = new BufferedInputStream(fin);
		DataInputStream in = new DataInputStream(bin);
		while ((s = in.readLine()) != null) {
			sum += Double.valueOf(s).doubleValue();
		}
	} catch (Exception e) {
		; //eof
	}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = sum + " " + dt;
	System.out.println(ret);
	return ret;
}

}
