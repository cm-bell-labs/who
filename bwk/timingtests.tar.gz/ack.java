import java.io.*;
import java.util.*;

public class ack {

public int ackf(int m, int n) {
	if (m == 0)
                return n+1;
        else if (n == 0)
                return ackf(m-1, 1);
        else
                return ackf(m-1, ackf(m, n-1));
}

public static void main(String args[]) throws IOException {
	ack a = new ack();
	a.runack(args);
}

public String runack(String args[]) {
	int m = Integer.parseInt(args[0]);
	int n = Integer.parseInt(args[1]);

	Date d0 = new Date();

	int a = ackf(m, n);

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = a + " " + dt + " msec";
	System.out.println(ret);
	return ret;
}

}
