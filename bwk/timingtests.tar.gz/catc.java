import java.io.*;
import java.util.*;

public class catc {

public static void main(String args[]) throws IOException {
	int b;

	BufferedInputStream in = new BufferedInputStream(System.in);
	BufferedOutputStream out = new BufferedOutputStream(System.out);
	Date d0 = new Date();
	try {
		while ((b = in.read()) > 0) {
			;
			out.write(b);
		}
	} catch (Exception e) {;}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();

	System.out.println(dt + " msec");
}

}
