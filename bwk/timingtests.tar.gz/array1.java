import java.io.*;
import java.util.*;

public class array1 {

public static void main(String args[]) throws IOException {
	array1 a = new array1();
	a.runarray1(args);
}

public String runarray1(String args[]) {

	int n = Integer.parseInt(args[0]);
	int ip[] = new int[n];
	int jp[] = new int[n];
	int i, j, m;

	Date d0 = new Date();
	m = 0;
	for (i = 0; i < n; i++)
		ip[i] = i ;
	for (j = n-1; j >= 0; j--)
		jp[j] = ip[j];

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = m + " " + dt + " msec";
	System.out.println(ret);
	return ret;
}

}
