$[ = 1;			# set array base to 1
$\ = "\n";		# set output record separator

$n = $ARGV[1] + 0;
for ($i = 1; $i <= $n; $i++) {
    $X{sprintf('%x', $i)} = $i;
}
for ($i = $n; $i > 0; $i--) {
    if (defined $X{$i}) {
	$c++;
    }
}
print $c;
