# reverse input by line to test assoc array mech.

$, = ' ';               # set output field separator

while (<>) {
    $X[$.] = $_;
}

for ($i = $.; $i > 0; $i--) {
    print $X[$i];
}
