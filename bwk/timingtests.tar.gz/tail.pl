# reads entire input at one go.

@a = <>;

for ($i = $#a; $i >= 0; $i--) {
    print $a[$i];
}
