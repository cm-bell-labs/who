$[ = 1;			# set array base to 1
$\ = "\n";		# set output record separator

$n = $ARGV[1] + 0;
for ($j = 0; $j < 10; $j++) {
    $S = 'abcdef';
    while (length($S) <= $n) {
	$S = '123' . $S . '456' . $S . '789';
	$S = substr($S, length($S) / 2) . substr($S, 1,	length($S) / 2);
    }
}
print length($S);
