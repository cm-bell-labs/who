import java.awt.*;
import java.util.*;

class gtest extends Frame {
	
Canvas cv = new Canvas();
Graphics g;
Button go = new Button("Go");
Button clear = new Button("Clear");
TextField n = new TextField("100", 15);
Button quit = new Button("Quit");

int MINX = 30;
int MINY = 30;
int MAXX= 580;
int MAXY = 380;

public static void main (String args[]) {
	gtest t = new gtest();
}

gtest() {
	setLayout(new FlowLayout());
	add(go);
	add(n);
	add(quit);
	add(cv);
	pack();
	g = getGraphics();
	resize(MAXX+30, MAXY+30);
	setBackground(Color.white);
	//g.paint();
	show();
}

public void doit() {
	int lim = Integer.parseInt(n.getText());
	int d = 8;
	double dx, dy;

	Date d0 = new Date();

	g.clearRect(0, 0, MAXX+30, MAXY+30);
	Toolkit.getDefaultToolkit().sync();
	dx = (double) (MAXX - MINX) / (double) lim;
	dy = (double) (MAXY - MINY) / (double) lim;
	for (int i = 1; i <= lim; i++) {
		g.setColor(Color.blue);
		g.drawLine(MINX, MINY, MAXX, MINY + (int) (i * dy));
		g.setColor(Color.black);
		g.fillOval(MAXX, MINY + (int) (i * dy), d, d);
		g.setColor(Color.red);
		g.drawOval(MAXX+2, MINY + (int) (i * dy)+2, d-4, d-4);
		//repaint();
		// Toolkit.getDefaultToolkit().sync();
	}
	for (int i = 1; i <= lim; i++) {
		g.setColor(Color.blue);
		g.drawLine(MINX, MINY, MINX + (int) (i * dx), MAXY);
		g.setColor(Color.black);
		g.fillOval(MINX + (int) (i * dx), MAXY, d, d);
		g.setColor(Color.red);
		g.fillOval(MINX + (int) (i * dx)+2, MAXY+2, d-4, d-4);
		//repaint();
		// Toolkit.getDefaultToolkit().sync();
	}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	g.setColor(Color.black);
	g.drawString("time = " + dt + "\n", 100, 100);
}

public boolean action(Event e, Object what) 
{
	boolean stat = true;
	String retval = "";

	Date d0 = new Date();
	if (e.target == quit) {
		hide();
		dispose();
		System.exit(0);
	} else if (e.target == go) {
		doit();
	} else {
		stat = false;
	}
	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	System.err.println(dt + " msec");
	return stat;
}

}
