$\ = "\n";              # set output record separator

$[ = 1;                 # set array base to 1

$m = $ARGV[1] + 0;
$n = $ARGV[2] + 0;
    print &ack($m, $n);

sub ack {
    local($M, $n) = @_;
    if ($M == 0) {
        return $n + 1;
    }
    if ($n == 0) {
        return &ack($M - 1, 1);
    }
    &ack($M - 1, &ack($M, $n - 1));
}
