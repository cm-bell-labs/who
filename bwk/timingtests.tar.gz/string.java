import java.io.*;
import java.util.*;

public class string {

public static void main(String args[]) throws IOException {
	string a = new string();
	a.runstring(args);
}

public String runstring(String args[]) {

	int n = Integer.parseInt(args[0]);
	int i, j;
	String s = "";

	Date d0 = new Date();
	for (j = 0; j < 10; j++) {
		s = "abcdef";
		while (s.length() <= n) {
			s = "123" + s + "456" + s + "789";
			s = s.substring(s.length()/2) + 
				s.substring(0, s.length()/2+1);
		}
	}
	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = s.length() + " " + dt + " msec";
	System.out.println(ret);
	return ret;
}

}
