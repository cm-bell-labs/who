import java.io.*;
import java.util.*;

public class sumloop {

public static void main(String args[]) throws IOException {
	sumloop a = new sumloop();
	a.runsumloop(args);
}

public String runsumloop(String args[]) {

	int n = Integer.parseInt(args[0]);
	int i, sum;

	Date d0 = new Date();
	sum = 0;
	for (i = 0; i < n; i++)
		sum++;

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = sum + " " + dt + " msec";
	System.out.println(ret);
	return ret;
}

}
