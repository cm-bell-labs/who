while (<>) {
    print $_;
}
