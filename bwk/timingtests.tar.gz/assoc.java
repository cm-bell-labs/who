import java.io.*;
import java.util.*;

public class assoc {

public static void main(String args[]) throws IOException {
	assoc a = new assoc();
	a.runassoc(args);
}

public String runassoc(String args[]) {

	int n = Integer.parseInt(args[0]);
	int i, c;
	String s = "";
	Integer ii;
	Hashtable ht = new Hashtable();

	Date d0 = new Date();
	c = 0;
	for (i = 1; i <= n; i++)
		ht.put(Integer.toString(i, 16), new Integer(i));
	for (i = 1; i <= n; i++)
		if (ht.containsKey(i+""))
			c++;

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = c + "    " + dt + " msec";
	System.out.println(ret);
	return ret;
}

}
