# uses {} assoc arrays

$[ = 1;			# set array base to 1

$n = $ARGV[1] + 0;
for ($i = 0; $i < $n; $i++) {
    $X{$i} = $i ;
}
for ($j = $n - 1; $j >= 0; $j--) {
    $Y{$j} = $X{$j};
}
