$, = ' ';
$[ = 1;			# set array base to 1
$\ = "\n";		# set output record separator

while (<>) {
    @Fld = split;
    $nl++;
    $nc += length($_);
    $nw += $#Fld;
}

print $nl, $nw, $nc;
