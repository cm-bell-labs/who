// usage: tail input >output

import java.io.*;
import java.util.*;

public class tail {

public static void main(String args[]) {
	tail t = new tail();
	t.runtail(args);
}

public String runtail(String args[])  {
	String s;
	Vector v = new Vector(100);

	Date d0 = new Date();
	try {
		FileInputStream fin = new FileInputStream(args[0]);
		BufferedInputStream bin = new BufferedInputStream(fin);
		DataInputStream in = new DataInputStream(bin);
		DataOutputStream out = new DataOutputStream(System.out);

		for ( ; (s = in.readLine()) != null; ) {
			v.addElement(s);
		}
		in.close();

		for (int i = v.size()-1; i >= 0; i--) {
			out.writeBytes((String) v.elementAt(i));
			out.writeByte('\n');
		}
		out.close();
	} catch (Exception e) {
		e.printStackTrace(); //eof
	}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = v.size()-1 + " " + dt;
	System.err.println(ret);
	return ret;
}

}
