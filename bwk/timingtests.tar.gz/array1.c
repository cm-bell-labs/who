#include <stdio.h>
#include <stdlib.h>

main(int argc, char *argv[]) {
	int i, j, n;
	int *ip, *jp;

	if (argc == 1)
		n = 50000;
	else
		n = atoi(argv[1]);
	ip = (int *) malloc(n * sizeof(int));
	jp = (int *) malloc(n * sizeof(int));

	for (i = 0; i < n; i++)
		ip[i] = i ;
	for (j = n-1; j >= 0; j--)
		jp[j] = ip[j];
}
