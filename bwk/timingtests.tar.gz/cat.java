// usage: cat input output
// uses buffered input and output

import java.io.*;
import java.util.*;

public class cat {

public static void main(String args[]) throws IOException {
	cat t = new cat();
	t.runcat(args);
}

public String runcat(String args[])  {
	
	String s;
	int b;
	BufferedInputStream in;
	BufferedOutputStream out;

	try {
		in = new BufferedInputStream(new FileInputStream(args[0]));
		out = new BufferedOutputStream(new FileOutputStream(args[1]));
	} catch (Exception e) {
		System.err.println(e);
		return "" + e;
	}
	Date d0 = new Date();
	try {
		while ((b = in.read()) > -1) {
			out.write(b);
		}
		out.close();
	} catch (Exception e) {System.err.println(e);}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();
	String ret = dt + " msec";
	System.out.println(ret);
	return ret;
}

}
