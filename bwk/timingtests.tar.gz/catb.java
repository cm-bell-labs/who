// cat <input >output
// default (apparently unbuffered) i/o

import java.io.*;
import java.util.*;

public class catb {

public static void main(String args[]) throws IOException {
	int b;

	Date d0 = new Date();
	try {
		while ((b = System.in.read()) > 0) {
			;
			System.out.write(b);
		}
	} catch (Exception e) {;}

	Date d1 = new Date();
	long dt = d1.getTime() - d0.getTime();

	System.err.println(dt + " msec");
}

}
