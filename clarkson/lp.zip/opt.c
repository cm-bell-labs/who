/*
 * Ken Clarkson wrote this.  Copyright (c) 1995 by AT&T..
 * Permission to use, copy, modify, and distribute this software for any
 * purpose without fee is hereby granted, provided that this entire notice
 * is included in all copies of any software which is or includes a copy
 * or modification of this software and in all copies of the supporting
 * documentation for such software.
 * THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY.  IN PARTICULAR, NEITHER THE AUTHORS NOR AT&T MAKE ANY
 * REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
 * OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
 */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <time.h>

#include "opt.h"


#define NITERMAX 1073741823
	/*  = LONG_MAX/2 */

int	n,		/* number of constraints */
	sconstraint,	/* size of a constraint */
	sopt_point,	/* size of an optimum point */
	b,		/* max number of constraints determining an opt_point */
	seed;

constraint	*A[NMAX],	/* pointers to constraints */
		*constraints;


void swap(int i, int j){
	constraint	*temp;
	temp=A[i]; A[i]=A[j]; A[j]=temp;
}


void sample(int rn, int n) {

	int		i,j;

	for (i=0;i<rn;i++){
		j= i+ ((int)(NMAX*double_rand()) % (n-i)); /* not *exactly* random, but good enough */
		swap(i,j);	
	}
}

opt_point smaller_opt(int n){return small_opt(n);}


opt_point recur_opt(int n){


	int	i,j,
		rn =  (int) b*n/(sqrt((double) n)+b)+1, 
		failed;
	opt_point	x;

	if (3*rn > n) return smaller_opt(n);
	
	sample(rn,n);

	x=recur_opt(rn);
	for (failed=i=0; i<b; i++) {
		for (j=rn;j<n;j++) {
			if (fails(x,j)) {
			failed=1;
			swap(j,rn++);
			}
		}
		if (failed) x = recur_opt(rn); else return x;
	}
	for (j=rn; j<n; j++) assert(!fails(x,j));
	return x;
}

opt_point iter_opt(int n){

	int	W[NMAX]={0};
	int	i,j,
		it=0,
		temp,
		rn,
		failed = 1,
		w=2,
		b2 = (int) b*b/(1+b*b/(float)n);
	long	N = n;
	opt_point x;

	while (failed){
		it++;
		rn = 0;
		for (i=0;i<n;i++){
			if ((double_rand()*N) < b2<<(W[i]<<w)) {
				swap(i,rn);
				temp = W[i]; W[i] = W[rn]; W[rn]=temp;
				rn++;
			}

		}
		x = small_opt(rn);

		failed = 0;

		if (N > NITERMAX>>w){
			j=0;
			for (i=0;i<n;i++) if (W[i]!=0) W[i]--; else j++;
			N = (N + j)>>(1<<w);
		}	

		for (i=rn;i<n;i++){
			if (fails(x,i)) {
				failed++;
				N += 1<<(W[i]<<w);
				W[i]++;
			}
		}

	}
	return x;
}






opt_point seidel_opt_inner(int n, int inc) {

	int	i;
	opt_point x = small_opt(b);

	if (inc==b) return x;

	for (i=inc; i<n; i++){
		if (fails(x,i)) {
			swap(i,inc);
			x=seidel_opt_inner(i+1,inc+1);
			swap(i,inc);			
		}
	};
	return x;
}


opt_point seidel_opt(int n) {

	if (n < b) return small_opt(n);
	sample(n,n);
	return seidel_opt_inner(n,0);
}
