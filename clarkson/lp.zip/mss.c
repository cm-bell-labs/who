/*
 * Ken Clarkson wrote this.  Copyright (c) 1995 by AT&T..
 * Permission to use, copy, modify, and distribute this software for any
 * purpose without fee is hereby granted, provided that this entire notice
 * is included in all copies of any software which is or includes a copy
 * or modification of this software and in all copies of the supporting
 * documentation for such software.
 * THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY.  IN PARTICULAR, NEITHER THE AUTHORS NOR AT&T MAKE ANY
 * REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
 * OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
 */


#include <float.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/times.h>
#include <getopt.h>

#include "opt.h"


int	small_total;	/* total size of calls to small_opt */

constraint sum_squares(constraint *);
#define cstak_size 100000


/* routines in the port library */

extern iqp_(int*,opt_point,float*,int*,opt_point,int*,constraint*,
					int*,float*,float*,float*,int*,int*,int*);

/*     SUBROUTINE IQP(N, X, Q, IQ,          C, M, A, IA, B, BL, BU,
     1   IPRINT, MAXITR, IEQ)
*/

extern int istkin_(long*, long*);
extern int wrapup_(void);
struct {double ds[cstak_size];} cstak_;
#define cstak_1 cstak_
static long int	c__size = cstak_size,
		c__4 = 4;



void panic (char *s) {printf("%s\n", s); exit(3);}

int fails(opt_point x, int j){

	register double		sum = 0.0;
	register constraint	*tempx = x,
				*tempj = A[j];
	
	register int	i = sconstraint;
	
	while (--i) sum += (*(tempx++)  *  *(tempj++));

	return (2.0*FLT_EPSILON+sum + *tempx < *tempj);
}


int really_fails(opt_point x, int j){

	register double		sum = 0.0;
	register constraint	*tempx = x,
				*tempj = A[j];
	
	register int	i = sconstraint;

	
	while (--i) sum += (*(tempx++)  *  *(tempj++));

	return (4.0*FLT_EPSILON+sum + *tempx < *tempj);
}

opt_point small_opt(int n){

	opt_point	x=(float*)malloc(sopt_point*sizeof(float));
	float		*Q=(float*)malloc(sopt_point*sopt_point*sizeof(float)),
			*C=(float*)malloc(sopt_point*sizeof(float));
	constraint	*Aiqp=(constraint*)malloc(n*sconstraint*sizeof(constraint)),
			*B=(constraint*)malloc(n*sizeof(constraint)),
			*BL=(opt_point)malloc(sopt_point*sizeof(float)), /*oops*/
			*BU=(opt_point)malloc(sopt_point*sizeof(float));

	int		i,j,k=0,
			MAXITR=200,
			IPRINT=0,
			IEQ=0;


	small_total+=n;

	for (i=0;i<sopt_point*sopt_point;i++) Q[i]=0.0;
	
	for (i=0;i<sopt_point-1;i++) {
		Q[i*(sopt_point+1)]=2.0;
		C[i]=0.0;
	}
	C[sopt_point-1]=2.0;


	for (i=0;i<sopt_point;i++) {
		x[i]=0.0;
		BL[i]=-100.0;	/*-FLT_MAX/2.0;*/
		BU[i]=100.0;	/* FLT_MAX/2.0;*/
	}
	x[sopt_point-1] = 1000.0;	/*FLT_MAX/4.0;*/

	for (i=0; i<n; i++) B[i]=*(A[i]+sconstraint-1);
	for (j=0;j<sconstraint-1;j++){
		for (i=0;i<n;i++) {
			Aiqp[k++] = *(A[i]+j);
		}
	}
	for (i=0;i<n;i++){
		Aiqp[k++]=1.0;

	}



	

/*C PARAMETERS ON INPUT
C   N       ORDER OF PROBLEM
C   X       INITIAL GUESS, NEED NOT SATISFY CONSTRAINTS
C   Q       N X N SYMMETRIC MATRIX,MAY BE INDEFINITE.
C           MUST BE FILLED IN COMPLETELY, STRICTLY
C           LOWER TRIANGLE DESTROYED
C   IQ      LEADING DIMENSION OF Q. MUST BE AT LEAST N
C   C       VECTOR IN LINEAR TERM OF FUNCTION TO BE MINIMIZED
C   IEQ     NUMBER OF LINEAR EQUALITY CONSTRAINTS
C   M       NUMBER OF LINEAR INEQUALITY CONSTRAINTS
C   A       M X N MATRIX OF LINEAR CONSTRAINTS
C   IA      LEADING DIMENSION OF A, MUST BE AT LEAST M
C   B       RIGHT HAND SIDE VECTOR OF CONSTRAINTS
C   BL      LOWER BOUND ON VARIABLES
C   BU      UPPER BOUND ON VARIABLES
C   IPRINT  IF IPRINT IS GREATER THAN 0,THEN THE FUNCTION,GRADIENT,
C           APPROXIMATE SOLUTION WILL BE PRINTED EACH ITERATION.
C           FEASABILITY CONDITIONS FROM FEAS WILL ALSO BE PRINTED.
C  MAXITR   MAXIMUM NUMBER OF ITERATIONS PERMITTED
C
C OUTPUT PARAMETERS
C   X       SOLUTION OF THE PROBLEM
*/
	iqp_(&sconstraint,x,Q,&sconstraint,C,&n,Aiqp,&n,B,BL,BU,&IPRINT,&MAXITR,&IEQ);


	return x;
/*     SUBROUTINE IQP(N, X, Q, IQ,          C, M, A, IA, B, BL, BU,
     1   IPRINT, MAXITR, IEQ)
*/



}


constraint sum_squares(constraint *c){
	register double	sum = 0.0;
	register int	i=sconstraint;
	constraint d;

	while (--i) {
		d=*(c++);
		sum += d*d;
	}
	return sum/2.0;
}



void getdata(void){

	int ccount = 0;

	n=0;
	scanf("%d%d", &sconstraint, &seed);
	sopt_point = b = sconstraint;
/*	printf("sconstraint=%d, seed=%d, ", sconstraint, seed);fflush(stdout);*/

	A[0] = constraints = (constraint*)malloc(1000*sconstraint*sizeof(constraint));
							/* should be more general */
printf("beginfig(20);\n");
	while(scanf("%f",&constraints[ccount++])!=EOF){
		if (0==((ccount+1) % sconstraint)){
			constraints[ccount++]=sum_squares(A[n]);
			if ((++n)==NMAX) panic("constraint array size exceeded.");
			if (0==(n%1000)) {
				constraints = (constraint*) realloc(constraints,
					(n+1000)*sconstraint*sizeof(constraint));
			}
			A[n] = &constraints[ccount];
printf("dotlabel(nullpicture,(%Gq,%Gq));\n", *(A[n-1]),*(A[n-1]+1));
		}
	}

/*	printf("n=%d\n",n);fflush(stdout);*/
	if (1!=(ccount%sconstraint)){
		printf("ccount=%d...last constraint not fully given", ccount);
		panic("last constraint not fully given");
	}
printf("endfig;\n");

}


void	putout(opt_point x){
	int i;
	printf("\n...and the answer is:");
	for (i=0;i<sopt_point;i++) printf("%f ",x[i]);fflush(stdout);
	printf("\n");
/*	for (i=0; i<n; i++) assert(!really_fails(x,i));*/
}



void main(int argc, char **argv) {

	short option;

	getdata();
	init_rand(seed);
	istkin_(&c__size,&c__4);

	while ((option = getopt(argc, argv, "sicra?")) != EOF) {
		switch (option) {
/*
		case 'c':
			printf("iqp time = %f\n", iqp_time=get_time(&small_opt,n));
			printf("iter/iqp: %f\n", get_time(&iter_opt,n)/iqp_time);
			printf("recur/iqp: %f\n", get_time(&recur_opt,n)/iqp_time);
			printf("seidel/iqp: %f\n",get_time(&seidel_opt,n)/iqp_time);
			break;
*/
		case 's' :
			putout(seidel_opt(n)); break;
		case 'i' :
			putout(iter_opt(n)); break;
		case 'r' :
			putout(recur_opt(n)); break;
		case 'a' :
			putout(small_opt(n)); break;
		case '?' :
			panic("USAGE:  opt -sirac? < points \n");
		}
	}

	wrapup_();	/* port library stats */
}
