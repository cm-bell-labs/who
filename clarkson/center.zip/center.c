#include <float.h>
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <time.h>



#define DEBOUT stdout
#define DEBTR fprintf(DEBOUT, __FILE__ " line %d \n" ,__LINE__);fflush(DEBOUT);
#define DEBEXP(exp) fprintf(DEBOUT,#exp "=%G\n", (float) exp); fflush(DEBOUT);


#define SITESMAX 20000
#define MAXDIM 20

float	sites[SITESMAX],
	osites[SITESMAX];

int	dim = 0;
long	num_sites = 0;

#define FUZZ 1e-11


/*************************************
 * 	random numbers
 **************************************/

unsigned short X[3];
double drand48(void);
extern double erand48 (unsigned short X[3]);
double double_rand(void) {return erand48(X);}

void init_rand(long seed) {
	seed = (seed==0) ? (long)time(0) : seed;
	fprintf(stderr, "init_rand: seed = %ld\n", seed);
	fflush(stderr);
	X[1] = seed;
	srand48(seed);
}


/*************************************
 * 	I/O
 **************************************/

void get_sites(void) {

	long i,ir;
	int k;

	if (EOF == scanf("%d",&dim)) return;
	
	for (ir=i=0; i<SITESMAX-MAXDIM; i++,ir+=dim) {
		for (k=0; k<dim && scanf("%f", sites+ir+k)!=EOF; k++);
/*			sites[ir+k] /= 1e6;*/
		if (k!=dim) break;
	}
	if (k) {DEBEXP(k) DEBEXP(i) fprintf(stderr,"huhh?");fflush(stderr);exit(1);}
	if (i>=SITESMAX-MAXDIM-1) {
		fprintf(stderr,"ran out of room"); fflush(stderr); exit(1);
	}
	num_sites = i;
}


void print_point_d(double *point, int d) {

	int k;

	for (k=0;k<d;k++) printf(" %G", *(point+k));
	printf("\n");
	fflush(stdout);

}


void print_point(float *point, int d) {

	int k;

	for (k=0;k<d;k++) printf(" %G", *(point+k));
	printf("\n");
	fflush(stdout);

}

FILE *gfile;
void print_points_graph(int figno, float *point) {

	int j;

	gfile = fopen("gin.d","a");

	for (j=0;j<num_sites;j++) {
		fprintf(gfile,"%G\n", point[0]/1e6);
		point+=1;
	}
	fprintf(gfile, "E\n");
	fclose(gfile);
}




FILE *mp_file;
void print_points_mp(int figno, float *point) {

	int j;

/*	if (figno%2) return;*/
	mp_file = fopen("c.mp","a");
	fprintf(mp_file, "beginfig(%d);\n", figno+1);

/*	fprintf(mp_file, "draw (0,0)--(0,u)--(u,u)--(u,0)--cycle;\n"); */

fprintf(mp_file, "draw fullcircle scaled .2u shifted (.25u,.5u);\n");
fprintf(mp_file, "draw fullcircle scaled .1u shifted (1.5u,.5u);\n");
if (figno==7) fprintf(mp_file, "dotlabel.bot(btex $m$ etex, (.5u,.5u));\n");
	for (j=0;j<num_sites;j++) {
		fprintf(mp_file," draw (%fu,%fu);\n", point[0],point[1]);
		point+=2;
	}
	fprintf(mp_file , "endfig;\n");
	fclose(mp_file);
}










/*************************************
 * 	actual computation
 **************************************/


void swap (long b, long m) {

	float t;
	long i;

	for (i=0;i<dim;i++) {
		t = sites[b+i];
		sites[b+i] = sites[m+i];
		sites[m+i] = t;
	}
}



/*
 *   compute the Radon point of a set of sites;
 *	let A=matrix with sites as columns;
 *	find x with Ax=0 by picking random vector and
 *	removing linear span of rows from it by Gram Schmidt
 *	return Ax^+, where x^+=x in positive coordinates of x, otherwise 0
 *	
 */



void radon(float *ans, float *isites) {

	double imat[400],mat[400],s,ss;
	int i,j,k,jr,ir,lr=(dim+2)*(dim+1);

	for (ir=i=0;i<dim+2;i++,ir+=dim) {
		for (jr =j=0;j<dim;j++,jr+= dim+2) 
			imat[jr + i] = mat[jr + i] = isites[ir + j];
		mat[(dim+2)*dim+i] = 1;
	}



	do {
		for (k=0;k<dim+2;k++)
			mat[lr+k] = double_rand();
		ir = dim+2;
		for (i=1;i<dim+2;i++,ir+=dim+2) {
			for (j=i-1;j>=0;j--) {
				jr = j*(dim+2);
				for (k=s=ss=0;k<dim+2;k++) {
					s  += mat[jr+k]*mat[ir+k];
					ss += mat[jr+k]*mat[jr+k];
				}
				if (ss > FUZZ)
					for (k=0;k<dim+2;k++)
						mat[ir+k] -= s*mat[jr+k]/ss;
			}
		}
		for (k=s=0;k<dim+2;k++) s+= mat[lr+k]*mat[lr+k];
	} while (s<FUZZ);

	for (k=ss=0;k<dim+2;k++) if (mat[lr+k]>0) ss+= mat[lr+k];
	for (k=0;k<dim+2;k++) mat[lr+k] /= ss;
	for (ir=i=0;i<dim;i++,ir+=dim+2) {
		for (ss=s=k=0;k<dim+2;k++) {
			s+= mat[lr+k]*imat[ir+k];
			ss += imat[ir+k]*imat[ir+k];
		}
		s = abs(s)/sqrt(ss);
		if (s>FUZZ) {fprintf(stderr, "whoops!"); fflush(stderr); exit(1);}
		ans[i] = 0;
		for (k=0;k<dim+2;k++)
			if (mat[lr+k]>0) ans[i] += imat[ir+k]*mat[lr+k];
	}	
}
	



void iterate_radon (void) {

	long i,j,m,b;

	for (i=0;i<dim+6;i++) {
		for (j=0;j<num_sites;j++) {
			for (m=0;m<dim+2;m++){
				b= m + (double_rand() * (num_sites-m));
					/* not *exactly* random, but good enough */
				swap(b*dim,m*dim);
			}
			radon(osites+j*dim,sites);
		}
		memcpy(sites, osites,num_sites*dim*sizeof(float));
	}
}


/*
 * for some graphics for a paper
 */
void fake_iterate_radon (void) {

	long i,j,k,m,b;
	int q=5;

	for (i=0;i<7;i++) {
		for (j=0;j<num_sites;j++) {
			for (m=0;m<q+1;m++){
				b= m + (double_rand() * (num_sites-m));
				swap(b*dim,m*dim);
			}
			for (k=0;k<2;k++) for (m=k+1;m<q+1;m++)
				if (sites[m]<sites[k]) swap(k,m);
			osites[j] = sites[1];
		}
		memcpy(sites, osites,num_sites*dim*sizeof(float));
	}
}



void main(int argc, char **argv) {

	long i,jr,j;
	float s;

	init_rand(0);

	get_sites();
	DEBEXP(dim)
	DEBEXP(num_sites)

/*mp_file = fopen("c.mp","w");
fprintf(mp_file, "u=300pt;\npickup pencircle scaled 2pt;\n");
fclose(mp_file);
*/

	iterate_radon();

/*mp_file = fopen("c.mp","a");
fprintf(mp_file, "end\n");
fclose(mp_file);
*/

	printf("computed center: ");
	print_point(sites,dim);

	printf("mean of centers: ");
	for (i=0;i<dim;i++) {
		for (s=j=0,jr=i;j<num_sites;j++,jr+=dim) s+= sites[jr];
		fprintf(DEBOUT, " %G",s/num_sites);
	}
	fprintf(DEBOUT,"\n");
	exit(0);
}
